//
//  UIImageView+QData.h
//  Test_QNet
//
//  Created by WJChao 16/6/5.
//  Copyright © 2016年 WJChao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (QData)

- (void)setImageWithURL:(NSString *)imageURL placeholder:(NSString *)imageName;

@end
